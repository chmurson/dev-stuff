import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import ${COMPONENT_NAME} from './../${COMPONENT_NAME}';

describe('${COMPONENT_NAME}', () => {
    let consoleSpy;

    beforeAll(() => {
        consoleSpy = jest.spyOn(console, 'error');
    });

    describe('with default props', () => {
        const component = mountComponent();
        it('matches snapshots', () => {
            expect(toJson(component)).toMatchSnapshot();
        });      
    });

    it('shows no errors on console', () => {
        expect(consoleSpy).not.toHaveBeenCalled();
    });
});

/**
 * @param props
 * @return {ReactWrapper<React.Component["props"], React.Component["state"], React.Component> | ReactWrapper<any, any>}
 */
function mountComponent(props = {}) {
    return mount(<${COMPONENT_NAME}
        {...props}
    />);
}
