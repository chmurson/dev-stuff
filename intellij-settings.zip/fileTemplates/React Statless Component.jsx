import React from 'react';
import PropTypes from 'prop-types';

export default function ${NAME}({}){
    return ;
}

${NAME}.propTypes = {

};