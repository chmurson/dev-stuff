import React from 'react';
import PropTypes from 'prop-types';

export default class ${NAME} extends React.Component{

    static propTypes = {
    };
    
    constructor(props){
        super(props);
        
        this.state = {
            
        }
    }
    
    render(){
        return ;
    }
}

